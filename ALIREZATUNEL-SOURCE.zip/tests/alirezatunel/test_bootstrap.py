import hashlib, io, os, pathlib, shutil, subprocess, sys, tarfile, tempfile, unittest
ROOT=pathlib.Path(__file__).resolve().parents[2]
class Bootstrap(unittest.TestCase):
 def check(self,bad=False,stale=False,unsafe=False):
  with tempfile.TemporaryDirectory() as d:
   d=pathlib.Path(d);bin=d/'bin';bin.mkdir();fixtures=d/'files';fixtures.mkdir();marker=d/'installed'
   for c in ['bash','mktemp','rm','cmp','uname','dirname','sha256sum']:
    p=shutil.which(c)
    if p:(bin/c).symlink_to(p)
   (bin/'python3').symlink_to(sys.executable)
   for c in ['openssl','systemctl','ip','iptables','ping','modprobe','sysctl']:(bin/c).write_text('#!/bin/sh\nexit 0\n');(bin/c).chmod(0o755)
   runtime=fixtures/'ALIREZATUNEL-linux-amd64.tar.gz'
   with tarfile.open(runtime,'w:gz') as t:
    for name,data in [('install.sh',f'#!/bin/bash\n[[ "$2" == --no-build ]] || exit 5\necho "$1" > "{marker}"\n'),*([('../escape','bad')] if unsafe else [])]:
     v=data.encode();m=tarfile.TarInfo(name);m.size=len(v);m.mode=0o755;t.addfile(m,io.BytesIO(v))
   (fixtures/'SHA256SUMS').write_text(('0'*64 if bad else hashlib.sha256(runtime.read_bytes()).hexdigest())+'  '+runtime.name+'\n')
   (fixtures/'SOURCE.sha256').write_text('abc  ALIREZATUNEL-SOURCE.zip\n')
   (bin/'curl').write_text('#!'+sys.executable+'\nimport sys,pathlib,shutil\na=sys.argv[1:]; url=next(x for x in a if x.startswith("https://"));out=a[a.index("-o")+1];name=url.rsplit("/",1)[1]\nshutil.copyfile('+repr(str(fixtures))+'+"/"+name,out)\n'+('if "releases/latest" in url and name=="SOURCE.sha256":pathlib.Path(out).write_text("old source")\n' if stale else ''))
   (bin/'curl').chmod(0o755)
   env={**os.environ,'PATH':str(bin),'TMPDIR':str(d)}
   r=subprocess.run(['/bin/bash',str(ROOT/'bootstrap.sh'),'agent'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
   self.assertEqual(r.returncode==0,not(bad or stale or unsafe),r.stderr)
   self.assertEqual(marker.exists(),not(bad or stale or unsafe))
 def test_verified_package_without_compilation(self):self.check()
 def test_corrupt_download_refused(self):self.check(bad=True)
 def test_stale_release_refused(self):self.check(stale=True)
 def test_path_traversal_refused(self):self.check(unsafe=True)
if __name__=='__main__':unittest.main()
