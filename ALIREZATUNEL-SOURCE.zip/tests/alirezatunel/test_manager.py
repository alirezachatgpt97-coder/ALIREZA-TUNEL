import contextlib, importlib.util, io, json, os, pathlib, sqlite3, subprocess, tempfile, unittest
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('manager',ROOT/'scripts/alirezatunel-manager.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)

def openssl(*args,env=None):return subprocess.run(['openssl',*map(str,args)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
class Setup(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.d=pathlib.Path(self.tmp.name)
  self.conf=self.d/'panel.toml';self.conf.write_text('listen = "0.0.0.0:443"\npath = "k-example"\ndata_dir = '+json.dumps(str(self.d))+'\n')
  self.root=self.d/'root';self.root.mkdir()
  a=patch.object(m,'ROOT',self.root);a.start();self.addCleanup(a.stop)
  a=patch.object(m,'CONF',self.conf);a.start();self.addCleanup(a.stop)
 def test_atomic_private_write(self):
  p=self.root/'secret';m.private(p,'test');self.assertEqual(p.read_text(),'test');self.assertEqual(p.stat().st_mode&0o777,0o600)
 def test_updates_preserve_other_fields(self):
  m.set_fields({'listen':'[::]:443','cert_file':'/etc/letsencrypt/live/test/fullchain.pem'})
  self.assertEqual(m.fields()['path'],'k-example');self.assertEqual(m.fields()['listen'],'[::]:443')
 def test_public_identity(self):
  self.assertEqual(m.host_name('panel.example.org'),('panel.example.org',False));self.assertEqual(m.host_name('1.1.1.1'),('1.1.1.1',True))
  for bad in ['127.0.0.1','https://example.org','example.org/path','x;rm']:
   with self.subTest(bad=bad),self.assertRaises(ValueError):m.host_name(bad)
 def test_credential_copy_invalid_after_web_password_change(self):
  with sqlite3.connect(self.d/'panel.db') as c:c.execute('CREATE TABLE meta(key TEXT,value TEXT)');c.execute("INSERT INTO meta VALUES ('password_hash','new-hash')")
  m.private(self.root/'setup.json',json.dumps({'host':'panel.example.org'}));m.private(self.root/'credentials.json',json.dumps({'password':'STALE-SECRET','hash':'old-hash'}))
  o=io.StringIO()
  with contextlib.redirect_stdout(o):m.credentials()
  self.assertNotIn('STALE-SECRET',o.getvalue());self.assertIn('tun password',o.getvalue())
 def test_password_uses_stdin_and_root_only_copy(self):
  with patch('getpass.getpass',side_effect=['chosen-password-123','chosen-password-123']),patch.object(m,'password_hash',return_value='hash'),patch.object(m,'run') as r:m.reset_password()
  self.assertEqual(r.call_args.kwargs['input'],b'chosen-password-123\n');self.assertNotIn('chosen-password',str(r.call_args.args))
  self.assertEqual((self.root/'credentials.json').stat().st_mode&0o777,0o600)
 def test_no_start_after_certificate_failure(self):
  with patch.object(m.sys.stdin,'isatty',return_value=True),patch.object(m,'acquire_ssl',side_effect=ValueError('CA failed')),patch.object(m,'run') as r:
   with self.assertRaises(ValueError):m.configure()
  self.assertFalse(r.called)
 def test_real_tls_chain_name_and_key(self):
  root=self.d/'ca.pem';cakey=self.d/'ca.key';key=self.d/'server.key';csr=self.d/'server.csr';cert=self.d/'server.pem';full=self.d/'fullchain.pem';ext=self.d/'ext'
  openssl('req','-x509','-newkey','rsa:2048','-nodes','-keyout',cakey,'-out',root,'-subj','/CN=Local test CA','-days','2')
  openssl('req','-newkey','rsa:2048','-nodes','-keyout',key,'-out',csr,'-subj','/CN=panel.example.org')
  ext.write_text('subjectAltName=DNS:panel.example.org,IP:1.1.1.1\nextendedKeyUsage=serverAuth\n')
  openssl('x509','-req','-in',csr,'-CA',root,'-CAkey',cakey,'-CAcreateserial','-out',cert,'-days','2','-extfile',ext)
  full.write_bytes(cert.read_bytes()+root.read_bytes())
  with patch.dict(os.environ,{'SSL_CERT_FILE':str(root)}):
   m.validate_tls(str(full),str(key),'panel.example.org');m.validate_tls(str(full),str(key),'1.1.1.1')
   with self.assertRaises(subprocess.CalledProcessError):m.validate_tls(str(full),str(key),'wrong.example.org')
   with self.assertRaises(Exception):m.validate_tls(str(full),str(cakey),'panel.example.org')
  with self.assertRaises(subprocess.CalledProcessError):m.validate_tls(str(full),str(key),'panel.example.org')
 def test_live_certificate_paths_not_frozen_to_archive(self):
  live=self.d/'live.pem';archive=self.d/'old.pem';archive.write_text('old');live.symlink_to(archive)
  with patch('builtins.input',side_effect=['3','panel.example.org',str(live),str(self.d/'key')]),patch.object(m,'validate_tls'):
   _,c=m.acquire_ssl()
  self.assertEqual(c['cert_file'],str(live))
if __name__=='__main__':unittest.main()
