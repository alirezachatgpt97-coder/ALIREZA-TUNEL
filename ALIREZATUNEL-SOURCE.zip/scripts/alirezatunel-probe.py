#!/usr/bin/env python3
"""Authenticated bounded measurements through a private native BackPack mapping."""
import asyncio, contextlib, json, math, os, statistics, struct, sys, time
CHUNK=bytes(range(256))*256

async def exact(r,n): return await asyncio.wait_for(r.readexactly(n),4)

def latency(samples,sent):
    order=sorted(samples)
    def percentile(p): return round(order[min(len(order)-1,round((len(order)-1)*p))],2) if order else 0
    return dict(sent=sent,received=len(samples),p50_ms=percentile(.5),p99_ms=percentile(.99),jitter_ms=round(statistics.mean(abs(a-b) for a,b in zip(samples,samples[1:])),2) if len(samples)>1 else 0)

async def serve(c):
    token=c['token'].encode(); stop=asyncio.Event(); active=0
    async def client(r,w):
        nonlocal active
        active+=1
        try:
            if active>64:return
            first=await exact(r,12)
            if first==b'\r\n\r\n\x00\r\nQUIT\n':
                h=await exact(r,4); n=struct.unpack('!H',h[2:])[0]
                if n>512:return
                await exact(r,n);first=await exact(r,12)
            if first+await exact(r,52)!=token:return
            cmd=await exact(r,1)
            w.write(b'A');await w.drain()
            if cmd==b'Q':stop.set();return
            if cmd==b'P':
                while True:
                    p=await exact(r,8);w.write(p);await w.drain()
            elif cmd==b'D':
                end=time.monotonic()+125
                while time.monotonic()<end:w.write(CHUNK);await w.drain()
            elif cmd==b'U':
                size=0;end=time.monotonic()+125
                while time.monotonic()<end:
                    n=struct.unpack('!I',await exact(r,4))[0]
                    if n==0:break
                    if n>len(CHUNK):return
                    await exact(r,n);size+=n
                w.write(struct.pack('!Q',size));await w.drain()
        except (OSError,EOFError,asyncio.IncompleteReadError,TimeoutError,ConnectionError):pass
        finally:
            active-=1;w.close()
            with contextlib.suppress(Exception):await w.wait_closed()
    class Echo(asyncio.DatagramProtocol):
        def connection_made(self,t):self.t=t
        def datagram_received(self,data,addr):
            if data.startswith(token) and len(data)<=1420:
                self.t.sendto(data,addr)
                if data==token+b'Q':stop.set()
    server=await asyncio.start_server(client,c.get('bind','127.0.0.1'),c['target'])
    transport,_=await asyncio.get_running_loop().create_datagram_endpoint(Echo,local_addr=(c.get('bind','127.0.0.1'),c['target']))
    print('READY',flush=True)
    try:
        async with server:
            with contextlib.suppress(TimeoutError):await asyncio.wait_for(stop.wait(),180)
    finally:transport.close()

async def measure(c):
    token=c['token'].encode();seconds=max(1,min(60,int(c['seconds'])));streams=max(1,min(32,int(c['streams'])))
    host=c.get('host','127.0.0.1');port=c['front']
    async def connect(cmd):
        r,w=await asyncio.wait_for(asyncio.open_connection(host,port),15)
        w.write(token+cmd);await w.drain()
        try:
            if await exact(r,1)!=b'A':raise ValueError('Invalid probe acknowledgement')
        except BaseException:w.close();raise
        return r,w
    async def ping(over):
        values=[];sent=0
        r,w=await connect(b'P');end=time.monotonic()+over
        try:
            while time.monotonic()<end:
                stamp=struct.pack('!Q',sent);sent+=1;start=time.monotonic()
                try:
                    w.write(stamp);await w.drain()
                    if await exact(r,8)==stamp:values.append((time.monotonic()-start)*1000)
                except (TimeoutError,OSError,asyncio.IncompleteReadError):break
                await asyncio.sleep(.1)
        finally:w.close()
        return latency(values,sent)
    async def phase(cmd):
        pairs=await asyncio.gather(*(connect(cmd) for _ in range(streams)))
        start=time.monotonic();end=start+seconds
        async def stream(pair):
            r,w=pair;total=0
            try:
                if cmd==b'D':
                    while time.monotonic()<end:
                        data=await asyncio.wait_for(r.read(65536),max(.01,end-time.monotonic()))
                        if not data:break
                        total+=len(data)
                else:
                    while time.monotonic()<end:
                        w.write(struct.pack('!I',len(CHUNK))+CHUNK)
                        await asyncio.wait_for(w.drain(),4)
                    w.write(b'\x00'*4);await w.drain()
                    total=struct.unpack('!Q',await asyncio.wait_for(r.readexactly(8),15))[0]
            except TimeoutError:
                if cmd!=b'D':raise
            finally:w.close()
            return total
        loads=asyncio.create_task(ping(seconds))
        counts=await asyncio.gather(*(stream(p) for p in pairs))
        elapsed=max(seconds,time.monotonic()-start);l=await loads
        total=sum(counts);rate=round(total*8/elapsed/1e6,2)
        return dict(mbps=rate,peak_mbps=rate,bytes=total),l
    async def udp():
        import socket
        loop=asyncio.get_running_loop();sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);sock.setblocking(False)
        samples=[];total=0;start=time.monotonic();sent=0
        try:
            for i in range(25):
                data=token+struct.pack('!Q',i)+os.urandom(1348);t=time.monotonic();sent+=1
                await loop.sock_sendto(sock,data,(host,port))
                try:
                    reply,_=await asyncio.wait_for(loop.sock_recvfrom(sock,2048),.7)
                    if reply==data:samples.append((time.monotonic()-t)*1000);total+=len(data)
                except TimeoutError:pass
            return latency(samples,sent),dict(bytes=total,mbps=round(total*8/max(.001,time.monotonic()-start)/1e6,2),peak_mbps=0)
        finally:sock.close()
    try:
        if c.get('raw_udp'):
            u,rate=await udp()
            if not u['received']:raise ValueError('No authenticated UDP response through the tunnel')
            return dict(seconds=seconds,streams=1,idle=u,download=rate,upload=rate,download_latency=u,upload_latency=u,udp=u,notes=['Raw UDP: both rates are identical echo goodput, not separate directional capacity.'])
        idle=await ping(1.5)
        print('Idle latency measured',file=sys.stderr,flush=True)
        down,dl=await phase(b'D');print('Download complete',file=sys.stderr,flush=True)
        up,ul=await phase(b'U');print('Upload complete',file=sys.stderr,flush=True)
        u,_=await udp() if c.get('udp') else (None,None)
        return dict(seconds=seconds,streams=streams,idle=idle,download=down,upload=up,download_latency=dl,upload_latency=ul,udp=u,notes=['BackPack private mapping: actual forwarded data. Peak is the phase average; instantaneous peak is not sampled.'])
    finally:
        if c.get('raw_udp'):
            import socket
            with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
                sock.sendto(token+b'Q',(host,port))
        else:
            with contextlib.suppress(Exception):
                _,w=await connect(b'Q');w.close()

async def main():
    c=json.loads(sys.stdin.readline())
    if len(c.get('token',''))!=64 or not all(x in '0123456789abcdef' for x in c['token']):raise ValueError('Invalid probe token')
    if sys.argv[1]=='serve':await serve(c)
    else:print(json.dumps(await measure(c)),flush=True)

if __name__=='__main__':
    try:asyncio.run(main())
    except Exception as e:print(str(e),file=sys.stderr);sys.exit(1)
